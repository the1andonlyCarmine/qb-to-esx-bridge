-- shared/main.lua

QBCore = QBCore or {}
QBCore.Functions = QBCore.Functions or {}

-- export for both client and server
exports('GetCoreObject', function()
    return QBCore
end)
