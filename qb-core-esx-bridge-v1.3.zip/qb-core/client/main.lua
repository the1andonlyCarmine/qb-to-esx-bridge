-- client/main.lua

QBCore = QBCore or {}
QBCore.Functions = QBCore.Functions or {}
QBCore.ClientCallbacks = QBCore.ClientCallbacks or {}

exports('GetCoreObject', function()
    return QBCore
end)

function QBCore.Functions.TriggerCallback(name, cb, ...)
    QBCore.ClientCallbacks[name] = cb
    TriggerServerEvent('QBCore:Server:TriggerCallback', name, ...)
end

RegisterNetEvent('QBCore:Client:Callback', function(name, ...)
    if QBCore.ClientCallbacks[name] then
        QBCore.ClientCallbacks[name](...)
        QBCore.ClientCallbacks[name] = nil
    end
end)

function QBCore.Functions.Notify(msg, msgType, time)
    msgType = msgType or 'info'
    time = time or 5000
    BeginTextCommandThefeedPost("STRING")
    AddTextComponentSubstringPlayerName(msg)
    EndTextCommandThefeedPostTicker(false, false)
end
