-- server/main.lua

local oxInv = GetResourceState('ox_inventory') == 'started'

QBCore = QBCore or {}
QBCore.Functions = QBCore.Functions or {}
QBCore.ServerCallbacks = QBCore.ServerCallbacks or {}

-- export for server scripts
exports('GetCoreObject', function()
    return QBCore
end)

-- legacy QB event
AddEventHandler('QBCore:GetObject', function(cb)
    cb(QBCore)
end)

-- =========== ESX player -> QB-style wrapper ===========

local function makeCitizenId(identifier)
    if not identifier or identifier == '' then
        return ('ESX-%s'):format(math.random(111111, 999999))
    end
    identifier = identifier:gsub('license:', ''):gsub('steam:', '')
    return identifier:sub(1, 10):upper()
end

local function wrapPlayer(xPlayer)
    if not xPlayer then return nil end

    local src = xPlayer.source
    local citizenid = makeCitizenId(xPlayer.identifier)

    local self = {}

    self.PlayerData = {
        source    = src,
        citizenid = citizenid,
        job = {
            name  = xPlayer.job and xPlayer.job.name or 'unemployed',
            label = xPlayer.job and xPlayer.job.label or 'Unemployed',
            grade = xPlayer.job and xPlayer.job.grade or 0,
        },
        money = {
            cash = xPlayer.getMoney and xPlayer.getMoney() or 0,
            bank = (xPlayer.getAccount and xPlayer.getAccount('bank') and xPlayer.getAccount('bank').money) or 0,
        },
        gang = {
            name  = 'none',
            label = 'None',
            grade = 0
        },
        charinfo = {
            phone = (xPlayer.get and (xPlayer.get('phone_number') or xPlayer.get('phone'))) or nil
        }
    }

    function self.Functions() return self end

    function self.Functions.AddMoney(moneyType, amount, reason)
        if moneyType == 'cash' or moneyType == 'money' then
            xPlayer.addMoney(amount)
        elseif moneyType == 'bank' then
            xPlayer.addAccountMoney('bank', amount)
        end
    end

    function self.Functions.RemoveMoney(moneyType, amount, reason)
        if moneyType == 'cash' or moneyType == 'money' then
            xPlayer.removeMoney(amount)
        elseif moneyType == 'bank' then
            xPlayer.removeAccountMoney('bank', amount)
        end
    end

    function self.Functions.AddItem(item, amount, slot, info)
        amount = amount or 1
        if oxInv then
            return exports.ox_inventory:AddItem(src, item, amount, info or {}, slot)
        else
            xPlayer.addInventoryItem(item, amount)
            return true
        end
    end

    function self.Functions.RemoveItem(item, amount, slot)
        amount = amount or 1
        if oxInv then
            return exports.ox_inventory:RemoveItem(src, item, amount, slot)
        else
            xPlayer.removeInventoryItem(item, amount)
            return true
        end
    end

    function self.Functions.GetItemByName(item)
        if oxInv then
            local inv = exports.ox_inventory:GetInventory(src, false)
            if not inv or not inv.items then return nil end
            for _, v in pairs(inv.items) do
                if v.name == item then
                    return v
                end
            end
            return nil
        else
            local esxItem = xPlayer.getInventoryItem(item)
            if esxItem and esxItem.count and esxItem.count > 0 then
                return { name = esxItem.name, amount = esxItem.count }
            end
        end
    end

    function self.Functions.SetJob(job, grade)
        if xPlayer.setJob then
            xPlayer.setJob(job, grade or 0)
        end
        self.PlayerData.job.name = job
        self.PlayerData.job.grade = grade or 0
    end

    return self
end

-- =========== QBCore.Functions ===========

function QBCore.Functions.GetPlayer(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    return wrapPlayer(xPlayer)
end

function QBCore.Functions.GetPlayers()
    local xPlayers = ESX.GetExtendedPlayers()
    local list = {}
    for _, xP in pairs(xPlayers) do
        list[#list+1] = xP.source
    end
    return list
end

function QBCore.Functions.GetQBPlayers()
    return QBCore.Functions.GetPlayers()
end

function QBCore.Functions.GetIdentifier(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    return xPlayer and xPlayer.identifier or nil
end

function QBCore.Functions.GetPlayerByCitizenId(citizenid)
    local xPlayers = ESX.GetExtendedPlayers()
    for _, xP in pairs(xPlayers) do
        local cid = makeCitizenId(xP.identifier)
        if cid == citizenid then
            return wrapPlayer(xP)
        end
    end
end

function QBCore.Functions.GetPlayerByPhone(number)
    if not number then return nil end
    local xPlayers = ESX.GetExtendedPlayers()
    for _, xP in pairs(xPlayers) do
        local pNum = xP.get and (xP.get('phone_number') or xP.get('phone')) or nil
        if pNum and tostring(pNum) == tostring(number) then
            return wrapPlayer(xP)
        end
    end
    return nil
end

function QBCore.Functions.CreateCallback(name, cb)
    QBCore.ServerCallbacks[name] = cb
    ESX.RegisterServerCallback(name, function(source, cb2, ...)
        cb(source, cb2, ...)
    end)
end

RegisterNetEvent('QBCore:Server:TriggerCallback', function(name, ...)
    local src = source
    local cb = QBCore.ServerCallbacks[name]
    if cb then
        cb(src, function(...)
            TriggerClientEvent('QBCore:Client:Callback', src, name, ...)
        end, ...)
    end
end)

function QBCore.Functions.CreateUseableItem(item, cb)
    if oxInv then
        exports.ox_inventory:RegisterUseableItem(item, function(data, slot)
            local src = data.source
            cb(src, item)
        end)
    else
        ESX.RegisterUsableItem(item, function(source)
            cb(source, item)
        end)
    end
end

function QBCore.Functions.HasItem(source, items, amount)
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then return false end

    if type(items) == 'string' then
        local item = Player.Functions.GetItemByName(items)
        if not item then return false end
        return (item.amount or item.count or 0) >= (amount or 1)
    elseif type(items) == 'table' then
        for _, it in ipairs(items) do
            local item = Player.Functions.GetItemByName(it)
            if not item then return false end
        end
        return true
    end

    return false
end
