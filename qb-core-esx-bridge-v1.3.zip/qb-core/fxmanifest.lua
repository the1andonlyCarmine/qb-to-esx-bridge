fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'qb-core'
description 'QBCore → ESX compatibility bridge (ESX + ox_inventory)'
author 'the1andonlyCarmine'
version '0.1.3'

dependency 'es_extended'

shared_scripts {
    '@es_extended/imports.lua',
    'shared/main.lua'
}

server_scripts {
    'server/main.lua'
}

client_scripts {
    'client/main.lua'
}

server_export 'GetCoreObject'
